clc; clear; close all;

train = readtable ('train.csv'); %%%%%%%%%%%%%%%%%%CAMBIATO I NOMI: TEST TO TRAIN (SONO DATI DI TRAIN); ATT: CAMBIATA LA PROVENIENZA DEL FILE TRAIN.CSV
wp = train.wp1;
ws = train.ws;
wd = pi/180 * train.wd;
%% cancello 1 e 0
ws = ws(wp ~= 0 & wp ~= 1);
wd = wd(wp ~= 0 & wp ~= 1);
wp = wp(wp ~= 0 & wp ~= 1);

figure(1)
scatter(ws, wp, 'x');
title('scatter dati senza 0 e 1') % tolgo gli 0 e gli 1 per far funzionare la logit
xlabel('ws');
ylabel('wp');

%% logit
wpl = log(wp./(1-wp)); % faccio la logit dei dati, wpl = wp con logit
figure(2)
scatter(ws, wpl, 'x');
title('scatter dati trasformati')
xlabel('ws');
ylabel('logit wp');

%% filtraggio righe
ws = ws(wpl > -4 & wpl < 4);
wd = wd(wpl > -4 & wpl < 4);
wp = wp(wpl > -4 & wpl < 4);
wpl = wpl(wpl > -4 & wpl < 4);
figure(3)
scatter(ws, wpl, 'x');
title('scatter dati puliti')
xlabel('ws filtrato');
ylabel('logit wp filtrato');
hold on

%% modello lineare
% y = t1 + t2*x
% wp = t1 + t2*ws
phi = [ones(length(wpl), 1), ws];
[theta, dev] = lscov(phi, wpl);  % dev = deviazione standard

% antitrasformo phi*theta
wpe = exp(phi*theta)./(1 + exp(phi*theta)); % wpe = wp estimated. tolgo la logit
epsilon = wp - wpe;
ssr = epsilon' * epsilon;
rmse = sqrt(ssr/length(wp));


figure(4)
scatter(ws, wp, 'x');
title('modello lineare')
xlabel('ws');
ylabel('wp');
hold on
scatter(ws, wpe, '.' ,'yellow')


%% modello quadratico
% y = t1 + t2*ws +t3*ws^2
% wp = t1 + t2*ws
phi2 = [ones(length(wpl), 1), ws, ws.^2];
[theta2, dev2] = lscov(phi2, wpl);  % dev = deviazione standard

% antitrasformo phi2*theta2
wpe2 = exp(phi2*theta2)./(1 + exp(phi2*theta2)); % wpe2 = wp estimated
epsilon2 = wp - wpe2;
ssr2 = epsilon2' * epsilon2;
rmse2 = sqrt(ssr2/length(wp));

figure(5)
scatter(ws, wp, 'x');
title('modello quadratico')
xlabel('ws');
ylabel('wp');
hold on
scatter(ws, wpe2, '.', 'red')


%% modello cubico
% y = t1 + t2*ws +t3*ws^2 + t4*ws^3
% wp = t1 + t2*ws
phi3 = [ones(length(wpl), 1), ws, ws.^2, ws.^3];
[theta3, dev3] = lscov(phi3, wpl);  % dev = deviazione standard

% antitrasformo phi2*theta2
wpe3 = exp(phi3*theta3)./(1 + exp(phi3*theta3)); % wpe3 = wp estimated
epsilon3 = wp - wpe3;
ssr3 = epsilon3' * epsilon3;
rmse3 = sqrt(ssr3/length(wp));
figure(6)
scatter(ws, wp, 'x');
title('modello cubico')
xlabel('ws');
ylabel('wp');
hold on
scatter(ws, wpe3, '.', 'black')


%% modello trigonometrico
% y = t1 + t2*ws +t3*cos(wd) + t4*sin(wd)

phit = [ones(length(wpl), 1), ws, cos(wd), sin(wd)];
[thetat, devt] = lscov(phit, wpl);  % devt = deviazione standard

% antitrasformo phit*thetat
wpet = exp(phit*thetat)./(1 + exp(phit*thetat)); % wpet = wp estimated
epsilont = wp - wpet;
ssrt = epsilont' * epsilont;
rmset = sqrt(ssrt/length(wp));
figure(7)
scatter3(ws, wd, wp, 'x');
title('modello trigonometrico')
xlabel('ws');
ylabel('wd');
zlabel('wp');
hold on
scatter3(ws, wd, wpet, '.', 'green')




%% Modello teorico
% y = ws; x = wp;
%chiedere perchè il parametro stimato viene 0.0028 e non circa 2500*pi*1.225
%perchè rmse sono molto differenti fra identificazione e validazione

my_fun = @(rA, ws) (0.5*(rA*ws.^3)); %my_fun modello teorico @ parametri che si passano
initials = pi * 50^2 * 1.225; %ipotizzo R = 50
[rA, residuals] = nlinfit(ws, wp, my_fun, initials);
wpt = my_fun(rA, ws); % wpt = wp teorica

rmseth = sqrt((residuals'*residuals)/length(wpt)); %rmset = rmse teorico
figure(8)
scatter(ws, wp, 'x');
xlabel('ws');
ylabel('wp');
hold on
scatter(ws, wpt, '.', 'yellow')
title('modello teorico con identificazione non lineare')
ylim([0 1])
% raggio compreso fra 10 e 85 metri, ipotizzo un raggio di 50 metri

%1.225 kg/m^3

%% rappresentazione dei modelli con logit

figure(3)
scatter(ws, wpl, 'x');
title('scatter dati puliti')
xlabel('ws filtrato');
ylabel('logit wp filtrato');
hold on
scatter(ws, phi*theta, '.', 'yellow');
scatter(ws, phi2*theta2, '.', 'green');
scatter(ws, phi3*theta3, '.', 'blue');
% plot3(ws, wd, phit*thetat);

%%
% confrontando rmse (del modello lineare) e rmset (del modello teorico)
% essendo dello stesso ordine vince il modello lineare %%%%%%%%%%%(non è meglio quello trigonometrico che tiene in considerazione un altro parametro e riduce seppur di poco ssr)

%% validazione dei modelli

%carico i dati di test

test = readtable('test.csv');
wp_test = test.wp1;
ws_test = test.ws;
wd_test = pi/180 * test.wd;

%%crossvalidazione

%matrici dei parametri dati validazione
phiV = [ones(length(wp_test), 1), ws_test];
phi2V = [ones(length(wp_test), 1), ws_test, ws_test.^2];
phi3V = [ones(length(wp_test), 1), ws_test, ws_test.^2, ws_test.^3];
phitV = [ones(length(wp_test), 1), ws_test, cos(wd_test), sin(wd_test)];

%potenze stimate di validazione usando i phi_Val  e i theta_Id
wpeV = phiV * theta; 
wpeV2 = phi2V * theta2;
wpeV3 = phi3V * theta3;
wpeVt = phitV * thetat;
wpVth = my_fun(rA, ws_test);

%residui fra previsione potenze e potenze di validazione
epsilonV = wp_test - wpeV;
epsilonV2 = wp_test - wpeV2;
epsilonV3 = wp_test - wpeV3;
epsilonVt = wp_test - wpeVt;
epsilonVth = wp_test - wpVth;

%sono gli ssr
ssrV = epsilonV' * epsilonV;
ssrV2 = epsilonV2' * epsilonV2;
ssrV3 = epsilonV3' * epsilonV3;
ssrVt = epsilonVt' * epsilonVt;
ssrVth = epsilonVth' * epsilonVth;

%mrseV
msreV=sqrt(ssrV/length(wp_test));
msreV2=sqrt(ssrV2/length(wp_test));
msreV3=sqrt(ssrV3/length(wp_test));
msreVt=sqrt(ssrVt/length(wp_test));
msreVth=sqrt(ssrVth/length(wp_test));

%lungo y i dati stimati e lungo x i dati reali
%fare superficie con meshgrid