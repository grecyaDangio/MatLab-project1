%% lettura dati
DS = readtable ('../progettino/test.csv');
wpv = DS.wp1;
wsv = DS.ws;
wdv = DS.wd;
%la v sta per validazione

%% devo costruire le phi di validazione per ogni modello

%% logit
wplv = log(wpv./(1-wpv)); % faccio la logit dei dati, wpl = wp con logit
figure(1)
scatter(wsv, wplv, 'x');
title('scatter dati trasformati')
xlabel('ws validazione');
ylabel('logit wp validazione');

%% filtraggio righe
wsv = wsv(wplv > -4 & wplv < 4);
wdv = wdv(wplv > -4 & wplv < 4);
wpv = wpv(wplv > -4 & wplv < 4);
wplv = wplv(wplv > -4 & wplv < 4);
figure(2)
scatter(wsv, wplv, 'x');
title('scatter dati trasformati e puliti')
xlabel('ws validazione puliti');
ylabel('logit wp validazione puliti');



%% modello lineare
% y = t1 + t2*x
% wp = t1 + t2*ws
phiv = [ones(length(wplv), 1), wsv];
yv = phiv*theta;
% antitrasformo phi*theta
wpev = exp(yv)./(1 + exp(yv)); % wpev = wp estimated. tolgo la logit
epsilonv = wpv - wpev;
ssrv = epsilonv' * epsilonv;
rmsev = sqrt(ssrv/length(wpv));


figure(2)
scatter(wsv, wpv, 'x');
title('modello lineare')
xlabel('ws');
ylabel('wp');
hold on
scatter(wsv, wpev, 'yellow')